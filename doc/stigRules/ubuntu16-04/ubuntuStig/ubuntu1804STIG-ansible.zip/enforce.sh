ansible-playbook -v -b -i /dev/null site.yml -e 'ansible_python_interpreter=/usr/bin/python3'
